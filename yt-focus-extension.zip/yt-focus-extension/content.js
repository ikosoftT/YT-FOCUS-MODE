/* ==========================================
   YT FOCUS MODE — content.js
   Handles dynamic YouTube SPA navigation
   ========================================== */

"use strict";

const SETTINGS_DEFAULTS = {
  blockHome: true,
  blockSidebar: true,
  blockShorts: true,
  blockEndCards: true,
  blockAutoplay: true,
  blockAds: true,
  blockNotifications: true,
  blockComments: false,
  enabled: true,
};

let settings = { ...SETTINGS_DEFAULTS };
let observer = null;
let placeholderInjected = false;

// ── Load settings then initialise ──────────────────────────────────────────
chrome.storage.sync.get(SETTINGS_DEFAULTS, (stored) => {
  settings = { ...SETTINGS_DEFAULTS, ...stored };
  init();
});

chrome.storage.onChanged.addListener((changes) => {
  for (const [key, { newValue }] of Object.entries(changes)) {
    settings[key] = newValue;
  }
  applyAll();
});

// ── Main init ──────────────────────────────────────────────────────────────
function init() {
  applyAll();
  watchNavigation();
}

// ── YouTube SPA navigation watcher ────────────────────────────────────────
function watchNavigation() {
  // yt-navigate-finish fires on every page change inside YT SPA
  document.addEventListener("yt-navigate-finish", () => {
    placeholderInjected = false;
    applyAll();
  });

  // Also watch for DOM mutations (YT lazily renders content)
  if (observer) observer.disconnect();
  observer = new MutationObserver(debounce(applyAll, 150));
  observer.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true,
  });
}

// ── Apply everything ───────────────────────────────────────────────────────
function applyAll() {
  if (!settings.enabled) {
    removePlaceholder();
    return;
  }

  const page = detectPage();

  if (settings.blockHome && page === "home") {
    injectHomePlaceholder();
    hideHomeContent();
  } else {
    removePlaceholder();
  }

  if (settings.blockSidebar && page === "watch") {
    hideSidebarRecommendations();
  }

  if (settings.blockShorts) {
    hideShorts();
  }

  if (settings.blockEndCards) {
    hideEndCards();
  }

  if (settings.blockAutoplay) {
    disableAutoplay();
  }

  if (settings.blockAds) {
    skipAds();
  }

  if (settings.blockComments) {
    hideComments();
  }
}

// ── Page detection ─────────────────────────────────────────────────────────
function detectPage() {
  const path = location.pathname;
  if (path === "/" || path === "/feed/subscriptions") return "home";
  if (path.startsWith("/watch")) return "watch";
  if (path.startsWith("/results")) return "search";
  if (path.startsWith("/shorts")) return "shorts";
  return "other";
}

// ── Home page ──────────────────────────────────────────────────────────────
function hideHomeContent() {
  // Hide the rich grid of recommended videos
  const selectors = [
    "ytd-rich-grid-renderer",
    "ytd-rich-grid-row",
    "#contents.ytd-rich-grid-renderer",
    "ytd-feed-filter-chip-bar-renderer",
  ];
  selectors.forEach((sel) => {
    document.querySelectorAll(sel).forEach((el) => {
      el.style.setProperty("display", "none", "important");
    });
  });
}

function injectHomePlaceholder() {
  if (placeholderInjected) return;
  const primary = document.querySelector(
    'ytd-browse[page-subtype="home"] #primary, #primary'
  );
  if (!primary) return;

  // Don't inject if already there
  if (document.getElementById("ytfm-home-placeholder")) {
    placeholderInjected = true;
    return;
  }

  const div = document.createElement("div");
  div.id = "ytfm-home-placeholder";
  div.innerHTML = `
    <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
      <rect x="8" y="8" width="48" height="48" rx="12" stroke="currentColor" stroke-width="3"/>
      <path d="M26 22l16 10-16 10V22z" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>
    </svg>
    <h2>Focus Mode is ON</h2>
    <p>Your homepage is hidden. Search for something you actually want to watch.</p>
    <span class="ytfm-search-hint">🔍 Use the search bar above</span>
  `;
  primary.prepend(div);
  placeholderInjected = true;
}

function removePlaceholder() {
  const el = document.getElementById("ytfm-home-placeholder");
  if (el) el.remove();
  placeholderInjected = false;
}

// ── Watch page sidebar ─────────────────────────────────────────────────────
function hideSidebarRecommendations() {
  const selectors = [
    "ytd-compact-video-renderer",
    "ytd-compact-radio-renderer",
    "ytd-compact-mix-renderer",
    "ytd-compact-autoplay-renderer",
    "ytd-watch-next-secondary-results-renderer",
  ];
  selectors.forEach((sel) => {
    document.querySelectorAll(sel).forEach((el) => {
      el.style.setProperty("display", "none", "important");
    });
  });
}

// ── Shorts ─────────────────────────────────────────────────────────────────
function hideShorts() {
  const selectors = [
    "ytd-rich-section-renderer",   // Shorts shelf on home
    "ytd-reel-shelf-renderer",     // Another shorts shelf variant
    '[overlay-style="SHORTS"]',    // Shorts thumbnail overlays
  ];
  selectors.forEach((sel) => {
    document.querySelectorAll(sel).forEach((el) => {
      el.style.setProperty("display", "none", "important");
    });
  });

  // Hide Shorts in the sidebar guide links
  document.querySelectorAll("ytd-guide-entry-renderer, ytd-mini-guide-entry-renderer").forEach((el) => {
    const link = el.querySelector("a");
    if (link && link.getAttribute("href") === "/shorts") {
      el.style.setProperty("display", "none", "important");
    }
  });
}

// ── End cards ─────────────────────────────────────────────────────────────
function hideEndCards() {
  document.querySelectorAll(".ytp-endscreen-content, .ytp-cards-button, .ytp-cards-teaser").forEach((el) => {
    el.style.setProperty("display", "none", "important");
  });
}

// ── Autoplay ───────────────────────────────────────────────────────────────
function disableAutoplay() {
  // Turn off the autoplay toggle if it's on
  const btn = document.querySelector(".ytp-autonav-toggle-button");
  if (btn) {
    const isOn = btn.getAttribute("aria-checked") === "true";
    if (isOn) btn.click();
    btn.closest(".ytp-autonav-toggle-button-container")?.style.setProperty("display", "none", "important");
  }
}

// ── Ad skipping ────────────────────────────────────────────────────────────
function skipAds() {
  // Click skip button if present
  const skipBtn = document.querySelector(".ytp-ad-skip-button, .ytp-skip-ad-button");
  if (skipBtn) {
    skipBtn.click();
    return;
  }

  // If unskippable ad is playing, jump to end
  const video = document.querySelector("video");
  const adBadge = document.querySelector(".ad-showing");
  if (video && adBadge && !video.paused) {
    video.currentTime = video.duration;
  }

  // Hide overlay ads
  document.querySelectorAll(
    ".ytp-ad-module, ytd-display-ad-renderer, ytd-promoted-video-renderer, " +
    "ytd-search-pyv-renderer, ytd-banner-promo-renderer, #masthead-ad, " +
    "ytd-masthead-ad, ytd-promoted-sparkles-text-search-renderer"
  ).forEach((el) => {
    el.style.setProperty("display", "none", "important");
  });
}

// ── Comments ───────────────────────────────────────────────────────────────
function hideComments() {
  const selectors = [
    "ytd-comments",                  // entire comments section
    "#comments",                     // comments container id
    "ytd-comment-thread-renderer",   // individual comment threads
    "#comment-teaser",               // comment teaser
  ];
  selectors.forEach((sel) => {
    document.querySelectorAll(sel).forEach((el) => {
      el.style.setProperty("display", "none", "important");
    });
  });
}

// ── Utility ────────────────────────────────────────────────────────────────
function debounce(fn, ms) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}
